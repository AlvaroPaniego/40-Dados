package com.example.dados_40

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
