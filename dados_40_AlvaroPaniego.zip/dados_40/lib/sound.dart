class Sound{
  String url;
  Sound(this.url);
}